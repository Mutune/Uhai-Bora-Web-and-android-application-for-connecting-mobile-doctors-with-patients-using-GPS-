export default {
  apiKey: "AIzaSyB3_gMtgsZ6HABR9MpVlDEgl9u7_RzWF4s",
  authDomain: "salutem-health.firebaseapp.com",
  databaseURL: "https://salutem-health.firebaseio.com",
  projectId: "salutem-health",
  storageBucket: "salutem-health.appspot.com",
  messagingSenderId: "120261116204",
  appId: "1:120261116204:web:522b1b391a7866ed"
};
