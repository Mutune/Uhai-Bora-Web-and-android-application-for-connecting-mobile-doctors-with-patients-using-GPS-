<template>
  <footer class="footer">
    <div class="container">
      <nav>
        <ul>
          <li>
            <a href="https://ikubij.github.io">James</a>
          </li>
          <li>
            <a href="#">
              Lennox
            </a>
          </li>
          <li>
            <a href="#">
              Tony
            </a>
          </li>
        </ul>
      </nav>
      <div class="copyright text-center">
        &copy; {{ new Date().getFullYear() }}
        <a href="#" target="_blank"
          >Salutare admin</a
        >, made with <i class="fa fa-heart heart"></i> 
      </div>
    </div>
  </footer>
</template>
<script>
export default {};
</script>
<style></style>
